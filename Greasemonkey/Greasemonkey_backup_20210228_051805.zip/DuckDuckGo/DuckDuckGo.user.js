// ==UserScript==
// @name     DuckDuckGo
// @version  1
// @grant    none
// ==/UserScript==
const logo = document.getElementsByClassName('header__logo-wrap')[0]
logo.href = 'https://tkiat.github.io'
logo.innerHTML = 'Hello! Theerawat'

Object.assign(logo.style, {
  color: 'blue',
  fontSize: "1.2em",
  textAlign: "center",
  lineHeight: '1.1em',
  fontWeight: 'bold',
  textDecoration: 'none'
});

logo.addEventListener("mouseover", event => {
  logo.style.color = 'red'
})

logo.addEventListener("mouseout", event => {
  logo.style.color = 'blue'
})