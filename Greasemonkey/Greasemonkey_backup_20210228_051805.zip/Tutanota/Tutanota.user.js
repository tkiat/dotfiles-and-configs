// ==UserScript==
// @name     Tutanota
// @version  1
// @grant    none
// ==/UserScript==

document.getElementsByClassName('logo')[0].innerHTML = 'Hello Theerawat!'